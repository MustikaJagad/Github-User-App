package com.dicoding.githubuser.data.model

data class UserResponse(
    val items : ArrayList<User>
)
